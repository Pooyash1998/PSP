var os__memory_8h =
[
    [ "os_free", "os__memory_8h.html#a345f569e1a9a5d0a6012c76ee1b0f65c", null ],
    [ "os_freeOwnerRestricted", "os__memory_8h.html#ae30934b438eca830815f445a1144a8c2", null ],
    [ "os_freeProcessMemory", "os__memory_8h.html#ac97dfa6f209b8979ac658f93814aa71f", null ],
    [ "os_getAllocationStrategy", "os__memory_8h.html#ac433fde93fe34efce81b77d82ba98773", null ],
    [ "os_getChunkSize", "os__memory_8h.html#af4b11f1dd58f3cec9668a6be98101be4", null ],
    [ "os_getFirstByteOfChunk", "os__memory_8h.html#a292385f9ee19516237f51ab76c76405e", null ],
    [ "os_getMapEntry", "os__memory_8h.html#a29ccc3e0a668c0be4b285bc74ef6d920", null ],
    [ "os_getMapSize", "os__memory_8h.html#a2038e0592b964adafe506b633dd310d6", null ],
    [ "os_getMapStart", "os__memory_8h.html#a3da86607df8a71aee3279f5e3ab99354", null ],
    [ "os_getUseSize", "os__memory_8h.html#af9bbb947c95cfa8b56540b3dd6c88e1c", null ],
    [ "os_getUseStart", "os__memory_8h.html#ade51aae9d1c897a830a2c6c3a4c5b2e6", null ],
    [ "os_malloc", "os__memory_8h.html#a5644c571680a5c019c91c30bee4d5d7e", null ],
    [ "os_realloc", "os__memory_8h.html#aff2d5210e82c9a0452f03876b050535f", null ],
    [ "os_setAllocationStrategy", "os__memory_8h.html#a6e809f1786f114791ae1e8d8abfb39d2", null ],
    [ "os_sh_close", "os__memory_8h.html#ab9125c3a1039f2e78695c58e2ea677b4", null ],
    [ "os_sh_free", "os__memory_8h.html#a37bb571969072dc0c70a318e819532e1", null ],
    [ "os_sh_malloc", "os__memory_8h.html#a99c86568d076bad5daab96f2c9aaca34", null ],
    [ "os_sh_read", "os__memory_8h.html#af2ba11755cec1002c426e890c3126043", null ],
    [ "os_sh_readOpen", "os__memory_8h.html#ab6c191363e0b7832ece936079d0aabf0", null ],
    [ "os_sh_write", "os__memory_8h.html#a586edb209da3e477d1658c5f326cab19", null ],
    [ "os_sh_writeOpen", "os__memory_8h.html#ad57af15912c724e047eee33b134d8d19", null ]
];