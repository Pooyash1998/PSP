var searchData=
[
  ['heap_41',['Heap',['../struct_heap.html',1,'Heap'],['../os__memheap__drivers_8h.html#a705af815969c97892c0aaaa658f6c88c',1,'Heap():&#160;os_memheap_drivers.h']]],
  ['heapoffset_42',['HEAPOFFSET',['../defines_8h.html#a46b527dcb3f8c0858e3d77682fc47b73',1,'defines.h']]]
];
