var searchData=
[
  ['_5f_5fheap_5fstart_498',['__heap_start',['../os__core_8h.html#a2e14a2c5e1049668b014d750223dcd43',1,'os_core.h']]]
];
