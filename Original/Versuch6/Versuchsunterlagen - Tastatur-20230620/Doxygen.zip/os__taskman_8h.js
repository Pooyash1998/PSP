var os__taskman_8h =
[
    [ "os_taskManMain", "os__taskman_8h.html#a95445fd0daa95f57aee301b431d6e18b", null ],
    [ "os_taskManOpen", "os__taskman_8h.html#a20fde36a5d165e7127203881ac5dc5d4", null ]
];