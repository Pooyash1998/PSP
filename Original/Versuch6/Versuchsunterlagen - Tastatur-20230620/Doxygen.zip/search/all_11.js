var searchData=
[
  ['savecontext_306',['saveContext',['../util_8h.html#a95d67df1cf6117ce43766d06b8113297',1,'util.h']]],
  ['schedulinginfo_307',['schedulingInfo',['../os__scheduling__strategies_8c.html#aadb0e3d669bbca5d4d424f4ba8724848',1,'os_scheduling_strategies.c']]],
  ['schedulinginformation_308',['SchedulingInformation',['../struct_scheduling_information.html',1,'SchedulingInformation'],['../os__scheduling__strategies_8h.html#a13aac67d6c5ae31dd05667417622ea64',1,'SchedulingInformation():&#160;os_scheduling_strategies.h']]],
  ['schedulingstrategy_309',['SchedulingStrategy',['../os__scheduler_8h.html#a19b2831a25a61b35337be0d5386f1098',1,'SchedulingStrategy():&#160;os_scheduler.h'],['../os__scheduler_8h.html#ac3ed7aa5fa89d4026cd86e4861ca7963',1,'SchedulingStrategy():&#160;os_scheduler.h']]],
  ['sethighnibble_310',['setHighNibble',['../os__memory_8c.html#a211f98b56ba22e7ec073c1b09b35d0ff',1,'os_memory.c']]],
  ['setlownibble_311',['setLowNibble',['../os__memory_8c.html#a79edcf2881c1b78d097495d05e7cec4f',1,'os_memory.c']]],
  ['setmapentry_312',['setMapEntry',['../os__memory_8c.html#aa0082364f445ac8cfacf8d0e873bcfb5',1,'os_memory.c']]],
  ['size_313',['size',['../struct_param_stack.html#a74382ab7f7e458ad64cc41ae089a806d',1,'ParamStack']]],
  ['spaces16_314',['spaces16',['../os__taskman_8c.html#a6ca767b35870fa6755c5ddae6ba13bdb',1,'os_taskman.c']]],
  ['spos_20manual_315',['SPOS Manual',['../index.html',1,'']]],
  ['stack_5fsize_5fisr_316',['STACK_SIZE_ISR',['../defines_8h.html#a5897211c66fb513c0e45424e77446325',1,'defines.h']]],
  ['stack_5fsize_5fmain_317',['STACK_SIZE_MAIN',['../defines_8h.html#a0187f5405175817f5d15b70f2d5ba908',1,'defines.h']]],
  ['stack_5fsize_5fproc_318',['STACK_SIZE_PROC',['../defines_8h.html#a69935146762e044c13bc1e04e159ac7f',1,'defines.h']]],
  ['stackchecksum_319',['StackChecksum',['../os__process_8h.html#a45db48aaf651fca0006e612d9a3b4b9b',1,'os_process.h']]],
  ['stackpointer_320',['StackPointer',['../os__process_8h.html#a52b6ead6aa07550bf81e7340e9d50e53',1,'StackPointer():&#160;os_process.h'],['../union_stack_pointer.html',1,'StackPointer']]],
  ['strategychanger_321',['strategyChanger',['../os__taskman_8c.html#a9f46441635483bb04c2857a3dbfdd925',1,'os_taskman.c']]],
  ['strategynamelookup_322',['StrategyNameLookup',['../os__taskman_8c.html#a1e1a679eb793791860ab397e5a177912',1,'os_taskman.c']]],
  ['strategyselector_323',['strategySelector',['../os__taskman_8c.html#acf1b1da1d6a9f250f3a0b0e5d57b62ea',1,'os_taskman.c']]],
  ['success_324',['success',['../struct_page_result.html#a26ab3f163c9b9e0ab50d0325dac0b921',1,'PageResult']]]
];
