var searchData=
[
  ['es_31',['ES',['../os__taskman_8c.html#a403811204922acc8d200abb94fa62fe4',1,'os_taskman.c']]],
  ['extheap_32',['extHeap',['../os__memheap__drivers_8h.html#a9d3e12d77e5d6a64c38d9d52a4aef469',1,'os_memheap_drivers.h']]],
  ['extheap_5f_5f_33',['extHeap__',['../os__memheap__drivers_8h.html#a5fd7ae6e8a4b4961b8c925b2625c96b8',1,'os_memheap_drivers.h']]]
];
