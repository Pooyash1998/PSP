var struct_key =
[
    [ "key", "struct_key.html#a32f04bf6b621ff119c184fb85bde522d", null ],
    [ "meta", "struct_key.html#aebb9ea1ce7eb55c8fc6ee01e961b3a9d", null ],
    [ "modifier", "struct_key.html#a46b25da371fdc6f2958243eceb11fe02", null ],
    [ "type", "struct_key.html#abfdf6a52caade2b7b45311a880cc5141", null ]
];